﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CoreFinal.Models
{
    public class CatagoryViewModel
    {
        public IEnumerable<Catagory> CatagorieVM { get; set; }
        public Catagory CatagoriEM { get; set; }
    }
}
