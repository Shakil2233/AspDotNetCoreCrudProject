using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using CoreFinal.Models;

namespace CoreFinal
{
    public class CatagoryController : Controller
    {
        public ApplicationDbContext _context;

        public CatagoryController(ApplicationDbContext context)
        {
            _context = context;
        }

        public IActionResult Index()
        {
            CatagoryViewModel catagoryViewModel = new CatagoryViewModel();
            catagoryViewModel.CatagorieVM = _context.Catagories.AsEnumerable();
            return View(catagoryViewModel.CatagorieVM);
        }

       
      
        public IActionResult Create()
        {
            return View();
        }

       
        [HttpPost]
      
        public async Task<IActionResult> Create(Catagory catagory)
        {
            if (ModelState.IsValid)
            {
                _context.Add(catagory);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(catagory);
        }

 
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var catagory = await _context.Catagories.FindAsync(id);
            if (catagory == null)
            {
                return NotFound();
            }
            return View(catagory);
        }

        
        [HttpPost]
    
        public async Task<IActionResult> Edit(int id, Catagory catagory)
        {
            if (id != catagory.ID)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(catagory);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!CatagoryExists(catagory.ID))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(catagory);
        }

       
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var catagory = await _context.Catagories
                .FirstOrDefaultAsync(m => m.ID == id);
            if (catagory == null)
            {
                return NotFound();
            }

            return View(catagory);
        }

      
        [HttpPost, ActionName("Delete")]
      
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var catagory = await _context.Catagories.FindAsync(id);
            _context.Catagories.Remove(catagory);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool CatagoryExists(int id)
        {
            return _context.Catagories.Any(e => e.ID == id);
        }
    }
}
